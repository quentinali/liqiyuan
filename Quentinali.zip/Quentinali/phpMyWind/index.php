<?php require_once(dirname(__FILE__).'/include/config.inc.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php echo GetHeader(); ?>
<link href="templates/default/style/webstyle.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="css/index.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/common.css"/>
<script  src="js/jquery.min.js"></script>
<script  src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="templates/default/js/jquery.min.js"></script>
<script type="text/javascript" src="templates/default/js/slideplay.js"></script>
<script type="text/javascript" src="templates/default/js/srcollimg.js"></script>
<script type="text/javascript" src="templates/default/js/loadimage.js"></script>
<script type="text/javascript" src="templates/default/js/top.js"></script>
<script type="text/javascript">
$(function(){
    $(".imgwrap li img").LoadImage({width:60,height:45});
	$(".newsfocus div img").LoadImage({width:60,height:60});
});
</script>
</head>
<body>
<!-- header-->
<?php require_once('header.php'); ?>
<!-- /header-->
<!-- banner-->
<div class="banner">
	<div id="slideplay">
		<ul>
			<?php
			$dosql->Execute("SELECT * FROM `#@__infoimg` WHERE classid=13 AND delstate='' AND checkinfo=true ORDER BY orderid ASC LIMIT 5,3");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
			?>
			<li><a href="<?php echo $gourl; ?>"><img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>" /></a></li>
			<?php
			}
			?>
		</ul>
	</div>
</div>
<!-- /banner-->

<!-- solutionlist-->
<div class="solution">
		<div class="aorise-title">
			<a href="solution.php">解决方案/Solution More</a>
		</div>
		<div class="aorise-wrap"></div>
		<div class="s-content">
			<div class="container">
				<div class="row">

				<?php
			$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=14  AND  flag LIKE '%h%'  AND  delstate='' AND checkinfo=true ORDER BY orderid ASC   LIMIT 0,3");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
			?>
                <div class="col-lg-4 col-md-4 col-xs-6">
                     <a href="<?php echo $row['linkurl']; ?>"> <img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>" />
                    <p><?php echo $row['title']; ?></p></a>
                </div>
                    <?php
			         }
			         ?>
				</div>
			</div>
		</div>
</div>
<!--end solutionlist-->

<!-- aboutuslist-->
<div class="about">
    <div class="aorise-title">
      <a href="about.php">关于我们/About Us More</a>
    </div>
    <div class="aorise-wrap"></div>
    <div class="a-content container">
       <div class="row">
				<?php
			$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=2  AND  flag LIKE '%a%'  AND  delstate='' AND checkinfo=true ORDER BY orderid ASC   LIMIT 0,4");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
			?>
                <div class="col-lg-3 col-md-3 col-xs-6">
	                <div class="a-hexagon">
	                	<div class="a-h-img">
                   <a href="<?php echo $row['linkurl']; ?>"> <img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>" />
                    <p><?php echo $row['title']; ?></p></a>
                		</div>
                	</div>
                </div>
                    <?php
			         }
			         ?>
				</div>
			</div>
		</div>
</div>
<!-- end aboutuslist-->
<!-- news-->
<div class="news">
	<div class="aorise-title">
      <a href="news.php">新闻资讯/NEWS More</a>
    </div>
    <div class="aorise-wrap"></div>
    <div class="container">
       <div class="row">
				<?php
			$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=4  AND  flag LIKE '%c%'  AND  delstate='' AND checkinfo=true ORDER BY orderid ASC   LIMIT 0,1");
			while($row = $dosql->GetArray())
			{
			?>
              <div class="n-left col-lg-6 col-md-6 col-xs-6">
                    		<a href="<?php echo $row['linkurl']; ?>"><img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?> "/></a>
                    		<p><?php echo $row['title']; ?></p>
                		</div>
                	<?php
			         }
			         ?>

               <?php
			$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=4  AND  flag LIKE '%a%'  AND  delstate='' AND checkinfo=true ORDER BY orderid ASC   LIMIT 0,10");
			while($row = $dosql->GetArray())
			{
			?>
              <div class="n-right col-lg-6 col-md-6 cl-xs-6">
              <ul>
                        <li><div class="three" style="
    display: inline-block;
    float: left;
    border-width: 8px;
    border-style: solid;
    border-color: transparent transparent transparent rgb(255, 0, 0);
    border-image: initial;
"></div><a href="<?php echo $row['gourl']; ?>"><?php echo $row['title']; ?></a><time datetime="2017-06-05"><?php echo GetDateTime($row['posttime']); ?></time></li><br/>
               </ul>
                		</div>
                    <?php
			         }
			         ?></div>
			</div>
		</div>
</div>

</div>
<!-- end news-->


<?php require_once('footer.php'); ?>
</body>
</html>
