
<!-- footer-->
<div class="footer">
 <div class="container">
       <div class="row">
          <div class="f-left col-lg-8 col-md-8 col-xs-6">
        <div class="f-img"><img src="images/header-logo.png" alt=" " /></div>
            <span>合作热线：4008745099 18307459777 公司地址：湖南省长沙市雨城区河西市政府大楼</span><br/>
           <?php echo $cfg_copyright ?><br />
            <span>本栏目文字内容归aorise.cn所有，任何单位及个人未经许可，不得擅自转载使用。</span>
        </div>
          <div class="f-right col-lg-4 col-md-8 col-xs-6">
            <img src="images/scanCode.PNG" alt=" " />
          </div>
       </div>
  </div>
 </div>
<!-- /footer-->
<?php

echo GetQQ();

//将流量统计代码放在页面最底部
$cfg_countcode;

?>